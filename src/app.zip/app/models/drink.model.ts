export interface Drink {
    idDrink: number;
    strDrink: string;
    strDrinkThumb: string;
  }