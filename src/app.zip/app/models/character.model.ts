export interface Character {
  id: number;
  name: string;
  image: string;
}
